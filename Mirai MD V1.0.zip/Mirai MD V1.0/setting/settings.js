// BASE CREATE BY RUZTANXD 
/* JANGAN DI HPS HARGAI GOBLOK

• APA BILAH KEHAPUS CREDITS MAKA DI ANGGAP DOSA BESAR 

# RuztanXD Bukan Sepuh ataupun Pengocok jandal RuztanXD cuma mau di anggap ada:) */


require("../all/module.js")

//========== Setting Owner ==========//
global.owner = "6285813708397","62881010487587"
global.idsaluran = "120363186130999681@newsletter"
global.namaowner = "FallZx Infinity"
global.namabot = "Mirai Kuriyama"
global.linkyt = 'https://www.youtube.com/@Fallzx-Features'
//SAWERIA 
global.mail = 'fallzxcoderid@gmail.com' // 

//========== Setting Event ==========//
global.autoread = false
global.anticall = true
global.autoreadsw = false
global.owneroff = false
global.autopromosi = false


//========== Setting Foto ===========//
global.imgreply = "https://pomf2.lain.la/f/7cebsj9s.jpg"
global.thumb = "https://pomf2.lain.la/f/k4d4saha.jpg"
//global.imgmenu = fs.readFileSync("./media/Menu.jpg")


//========== SERVER PRIVATE RUZTANXD==========//
global.domainn = "-"
global.apikeyy = "-"
global.capikeyy = "-"

//========== Setting Panell ==========//
global.eggsnya = '15' // id eggs yang dipakai kalo id nya 5 biarin aja ini jangan di ubah
global.location = '1' // id location
global.limitawal = 5

global.domain = '-' // Isi Domain Lu
global.apikey = '-' // Isi Apikey Plta Lu
global.capikey = '-' // Isi Apikey Pltc Lu

//========= Setting Payment =========//
//Kalo Gak Ada Isi Aja jadi "Gak Ada"
global.dana = "085813708397"
global.gopay = "085813708397"
global.ovo = "085813708397"
global.qris = "https://pomf2.lain.la/f/0laclvz.jpg"
                             

//========= Setting Message =========//
global.msg = {
"error": "Error terjasi kesalahan",
"done": "Done Kak ✅", 
"wait": "⏳Memproses . . .", 
"group": "Command Ini Hanya Untuk Didalam Grup", 
"private": "Command Ini Hanya Untuk Di Private Chat", 
"admin": "Command Ini Hanya Untuk Admin Grup", 
"adminbot": "Command Ini Dapat Di Gunakan Ketika Bot Menjadi Admin", 
"owner": "Maaf Command Ini Hanya Untuk Owner Bot", 
"developer": "Command Ini Hanya Untuk Developer Bot!"
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})