module.exports = {
  'approval': {
    'num': '6285813708397',
    'text': "setujui",
    'set': "👀 Harus mendapatkan persetujuan oleh creator script, Jika ingin memakai script ini",
    'greet': "*Disetujui Oleh Creator, Silahkan Restart Panel Atau Run Ulang script* ☠️ "
  },
  'creatorScript': '6285813708397',
  'filePath': "./all/approval",
  'checkFilePath': "../setting/Mirai.js",
  'codeToDetect': 'main();'
};